package cn.jpush.api.push.model;

import com.google.gson.JsonElement;

public interface PushModel {

    public JsonElement toJSON();
    
}
