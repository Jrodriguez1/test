package cn.jpush.api.common;

public enum TimeUnit {

    HOUR,
    DAY, 
    MONTH
    
    
}
