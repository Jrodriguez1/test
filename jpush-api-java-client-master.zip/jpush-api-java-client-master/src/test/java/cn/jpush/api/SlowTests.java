package cn.jpush.api;

public interface SlowTests {

}
