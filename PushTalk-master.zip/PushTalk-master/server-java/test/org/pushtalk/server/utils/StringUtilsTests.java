package org.pushtalk.server.utils;

public class StringUtilsTests {

    /**
     * @param args
     */
    public static void main(String[] args) {
        System.out.println(StringUtils.getRandomString().substring(0, 8));

    }

}
