package org.pushtalk.server.web.template;

public class TemplateIndicator {

}
