package org.pushtalk.android.utils;

/**
 * 
 * Indicator callback for proguard build
 *
 */
public interface JavascriptCallback {

}
