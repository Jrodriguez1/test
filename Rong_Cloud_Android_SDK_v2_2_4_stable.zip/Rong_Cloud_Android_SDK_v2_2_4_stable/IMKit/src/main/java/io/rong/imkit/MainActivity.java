package io.rong.imkit;

import android.app.Activity;

/**
 * Created by Bob on 15/7/7.
 */
public class MainActivity extends Activity {
}
